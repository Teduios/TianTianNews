//
//  AppDelegate+Category.h
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (Category)

- (void)initializeWithApplication:(UIApplication *)application;

@end
