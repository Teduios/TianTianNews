//
//  YJImageView.h
//  YJProject
//
//  Created by YangJian on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YJImageView : UIView
@property(nonatomic,strong)UIImageView *imageView;
@end
