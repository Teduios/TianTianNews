//
//  YJVideoViewController.h
//  YJProject
//
//  Created by YangJian on 15/11/21.
//  Copyright © 2015年 yangjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YJVideoViewController : UITableViewController

@end
