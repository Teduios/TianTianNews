//
//  YJLoginUserViewController.h
//  YJProject
//
//  Created by YangJian on 15/11/26.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YJMeViewController.h"
@interface YJLoginUserViewController : UIViewController
@property (nonatomic,strong) YJMeViewController *resultText;
@end
