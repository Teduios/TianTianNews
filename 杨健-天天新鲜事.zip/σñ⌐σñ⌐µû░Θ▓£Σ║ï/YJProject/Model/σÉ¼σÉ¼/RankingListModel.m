//
//  RankingListModel.m
//  YJProject
//
//  Created by YangJian on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankingListModel.h"

@implementation RankingListModel


+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [RankListListModel class]};
}
@end
@implementation RankListListModel

@end


